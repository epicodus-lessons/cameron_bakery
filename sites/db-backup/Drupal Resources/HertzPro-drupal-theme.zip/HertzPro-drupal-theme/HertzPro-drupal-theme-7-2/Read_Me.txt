Thank you for purchasing HertzPro Drupal 7 theme.

+===========================+
Theme Compatibility
+===========================+
Drupal 7.x.x



+===========================+
Theme Page
+===========================+
http://drupar.com/theme/hertzpro



+===========================+
Live Demo
+===========================+
http://demo.drupar.com/hertzpro/



+===========================+
Theme Documentation
+===========================+
Please read the theme documentation for easy and quick getting started.
http://drupar.com/hertzpro-theme-documentation/



+===========================+
Sample Content
+===========================+
Please find sample contents inside "sample_content" folder of the download file.



+===========================+
Theme Support
+===========================+
Please feel to ask theme related support queries on our support forum.
http://drupar.com/forum



+===========================+
Theme Support Policy
+===========================+
http://drupar.com/support-policy