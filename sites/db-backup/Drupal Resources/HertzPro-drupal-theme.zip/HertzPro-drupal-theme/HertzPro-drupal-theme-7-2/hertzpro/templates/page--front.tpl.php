<?php include (drupal_get_path('theme', 'hertzpro')."/includes/header.php"); ?>
<?php if (theme_get_setting('homepage_slider_show')): ?>
<?php include (drupal_get_path('theme', 'hertzpro')."/includes/slider.php"); ?>
<?php endif; ?>
<div id="content-body" class="container front-page clearfix">
	<section role="main" class="clearfix">
		<div class="clear"></div>
		<?php if ($page['homepage_content']): ?><!-- / start homepage content block -->
			<div class="full">
				<?php print render($page['homepage_content']); ?>
			</div> <!-- / end homepage content block -->
		<?php endif; ?>
		<div class="clear"></div>
	</section> <!-- /#main -->
</div> <!-- /#content-body --> 
<?php include (drupal_get_path('theme', 'hertzpro')."/includes/footer.php"); ?>