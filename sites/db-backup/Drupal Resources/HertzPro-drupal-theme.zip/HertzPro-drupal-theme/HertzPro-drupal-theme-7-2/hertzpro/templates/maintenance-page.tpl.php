<!DOCTYPE html>
<!--[if lt IE 7]> <html class="ie6 ie" lang="<?php print $language->language; ?>" dir="<?php print $language->dir; ?>"> <![endif]-->
<!--[if IE 7]>    <html class="ie7 ie" lang="<?php print $language->language; ?>" dir="<?php print $language->dir; ?>"> <![endif]-->
<!--[if IE 8]>    <html class="ie8 ie" lang="<?php print $language->language; ?>" dir="<?php print $language->dir; ?>"> <![endif]-->
<!--[if gt IE 8]> <!--> <html class="" lang="<?php print $language->language; ?>" dir="<?php print $language->dir; ?>"> <!--<![endif]-->
<head>
	<?php print $head; ?>
	<!-- Set the viewport width to device width for mobile -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<title><?php print $head_title; ?></title>
	<?php print $styles; ?>
	<?php print $scripts; ?>
	<!-- IE Fix for HTML5 Tags -->
	<!--[if lt IE 9]>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
</head>
<body class="<?php print $classes; ?>" <?php print $attributes;?>>
<div id="content">
	<div id="header">
		<div class="container clearfix">
			<?php if ($logo): ?>
			  <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" id="logo">
				<img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
			  </a>
			<?php endif; ?>
			<div id="social">
				<?php if (theme_get_setting('social_icons')): ?>
					<?php if(theme_get_setting('youtube_url')!=''): ?><li><a href="<?php echo theme_get_setting('youtube_url'); ?>" class="youtube icon" target="_blank" rel="me"></a></li><?php endif; ?>
					<?php if(theme_get_setting('instagram_url')!=''): ?><li><a href="<?php echo theme_get_setting('instagram_url'); ?>" class="instagram icon" target="_blank" rel="me"></a></li><?php endif; ?>
					<?php if(theme_get_setting('pinterest_url')!=''): ?><li><a href="<?php echo theme_get_setting('pinterest_url'); ?>" class="pinterest icon" target="_blank" rel="me"></a></li><?php endif; ?>
					<?php if(theme_get_setting('gplus_url')!=''): ?><li><a href="<?php echo theme_get_setting('gplus_url'); ?>" class="gplus icon" target="_blank" rel="me"></a></li><?php endif; ?>
					<?php if(theme_get_setting('linkedin_url')!=''): ?><li><a href="<?php echo theme_get_setting('linkedin_url'); ?>" class="linkedin icon" target="_blank" rel="me"></a></li><?php endif; ?>
					<?php if(theme_get_setting('twitter_url')!=''): ?><li><a href="<?php echo theme_get_setting('twitter_url'); ?>" class="twitter icon" target="_blank" rel="me"></a></li><?php endif; ?>
					<?php if(theme_get_setting('facebook_url')!=''): ?><li><a href="<?php echo theme_get_setting('facebook_url'); ?>" class="facebook icon" target="_blank" rel="me"></a></li><?php endif; ?>
				<?php endif; ?>
			</div> <!-- end #social -->
		</div><!--/.container -->
	</div><!--/#header -->
</div><!--/#content -->
<div id="maintenance-page" class="container clearfix">
    <?php print $messages; ?>
    <?php if ($title): ?><h1 class="title" id="page-title"><?php print $title; ?></h1><?php endif; ?>
	<img class="center" src="<?php print base_path() . drupal_get_path('theme', 'hertzpro') . '/images/maintenance.png'; ?>" alt="maintenance" />
    <?php print $content; ?>  
</div> <!-- /#maintenance-page -->
</body>
</html>