<?php if (!$page): ?>
<article id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?> clearfix"<?php print $attributes; ?>>
<?php endif; ?>
	<header>
		<?php if (!$page): ?>
				<h2 class="title" <?php print $title_attributes; ?>><a href="<?php print $node_url; ?>"><?php print $title; ?></a></h2>			
		<?php endif; ?>
		
		<?php if ($display_submitted): ?>
			<div class="submitted"><div class="submitted_by"><?php print $submitted; ?></div><div class="comments_count"><?php print $comment_count; ?> <?php print t('comments'); ?></div></div>		
		<?php endif; ?>
	</header>
	<div class="content">
		<?php
			// Hide comments, tags, and links now so that we can render them later.
			hide($content['comments']);
			hide($content['links']);
			hide($content['field_tags']);
			print render($content);
		?>
	</div> <!--/.content -->
	<footer>
		<?php if (!empty($content['field_tags']) || !empty($content['links'])): ?>
		<div class="footer-links"><?php print render($content['links']); ?></div>
		<div class="footer-tags"><?php print render($content['field_tags']); ?></div>
		<hr />
		<?php endif; ?>		
		<div class="node-comments"><?php print render($content['comments']); ?></div>
	</footer>
<?php if (!$page): ?>
</article> <!-- /.node -->
<?php endif; ?>