<div id="forum-post">
<?php if (!$page): ?>
<article id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?> clearfix"<?php print $attributes; ?>>
<?php endif; ?>
  <div class="post-user">
	  <?php print $user_picture ?>
	  <div class="post-meta">
		<h4><?php print $name; ?></h4>
		<?php print $submitted_day.' / '.$submitted_month.' / '.$submitted_year ?>
	  
	  </div>
  </div>
	<div class="forum-post">
		<div class="content"<?php print $content_attributes; ?>>
		<?php
			// Hide comments, tags, and links now so that we can render them later.
			hide($content['comments']);
			hide($content['links']);
			hide($content['field_tags']);
			print render($content);
		?>
		</div> <!-- /.content -->
		<?php if (!empty($content['field_tags']) || !empty($content['links'])): ?>
			<footer class="footer-links">
				<?php print render($content['field_tags']); ?>
				<?php print render($content['links']); ?>
			</footer>
		<?php endif; ?>
	</div> <!-- /.forum-post -->
  <?php print render($content['comments']); ?>
<?php if (!$page): ?>
</article> <!-- /.node -->
<?php endif; ?>
</div> <!-- /#forum-post -->