<article class="<?php print $classes . ' ' . $zebra; ?>"<?php print $attributes; ?>>
	<div class="comment-user">
		<?php print $picture ?>
		<div class="user-name"><h4><?php print $author; ?></h4></div>
	</div>
	<div class="comment-text">
		<header>
			<?php print render($title_prefix); ?>
			<h3<?php print $title_attributes; ?>><?php print $title ?></h3>
			<?php print render($title_suffix); ?>
			<div class="submitted"><?php print $created; ?></div>
			<?php if ($new): ?>
				<span class="new"><?php print $new ?></span>
			<?php endif; ?>
		</header>
		<div class="content"<?php print $content_attributes; ?>>
			<?php hide($content['links']); print render($content); ?>
			<?php if ($signature): ?>
			<div class="user-signature clearfix">
				<?php print $signature ?>
			</div>
			<?php endif; ?>
		</div>
		<?php if (!empty($content['links'])): ?>
		<footer>
			<?php print render($content['links']) ?>
		</footer>
		<?php endif; ?>
	</div> <!-- /.comment-text -->
</article> <!-- /.comment -->
