<?php if (!$page): ?>
<article id="node-<?php print $node->nid; ?>" class="<?php print $classes; ?> clearfix"<?php print $attributes; ?>>
<?php endif; ?>
<div id="gallery">
	<div class="content"<?php print $content_attributes; ?>>
		<?php
		// Hide comments, tags, and links now so that we can render them later.
		hide($content['comments']);
		hide($content['links']);
		hide($content['field_tags']);
		print render($content);
		?>
	</div>
	<div class="clear"></div>
	<footer>
		<?php if (!empty($content['field_tags']) || !empty($content['links'])): ?>
		<div class="footer-links"><?php print render($content['links']); ?></div>
		<div class="footer-tags"><?php print render($content['field_tags']); ?></div>
		<hr />
		<?php endif; ?>		
		<div class="node-comments"><?php print render($content['comments']); ?></div>
	</footer>
</div> <!-- /#gallery -->
<?php if (!$page): ?>
</article> <!-- /.node -->
<?php endif; ?>
