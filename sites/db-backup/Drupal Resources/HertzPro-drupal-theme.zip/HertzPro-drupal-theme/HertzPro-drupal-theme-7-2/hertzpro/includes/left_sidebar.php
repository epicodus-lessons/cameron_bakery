<?php if ($page['sidebar_first']): ?>
	<aside id="sidebar-first" role="complementary" class="sidebar clearfix">
	  <?php print render($page['sidebar_first']); ?>
	</aside>  <!-- /#sidebar-first -->
<?php endif; ?>