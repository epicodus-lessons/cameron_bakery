<?php if (theme_get_setting('header_message_bar')): ?>
	<div class="open-message-bar"></div>
	<div id="message-bar">
		<div class="container message-bar">
			<?php if ($page['message_bar']): ?>	
				<?php print render($page['message_bar']); ?>
			<?php endif; ?>
		</div> <!-- /.message-bar -->
	</div> <!-- /#message-bar -->
<?php endif; ?>
<div id="content">
<div id="header">
	<div class="container clearfix">
		<?php if ($logo): ?>
		  <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" id="logo">
			<img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
		  </a>
		<?php endif; ?>
		<div id="social">
			<?php if (theme_get_setting('social_icons')): ?>
				<?php if(theme_get_setting('youtube_url')!=''): ?><li><a href="<?php echo theme_get_setting('youtube_url'); ?>" class="youtube icon" target="_blank" rel="me"></a></li><?php endif; ?>
				<?php if(theme_get_setting('instagram_url')!=''): ?><li><a href="<?php echo theme_get_setting('instagram_url'); ?>" class="instagram icon" target="_blank" rel="me"></a></li><?php endif; ?>
				<?php if(theme_get_setting('pinterest_url')!=''): ?><li><a href="<?php echo theme_get_setting('pinterest_url'); ?>" class="pinterest icon" target="_blank" rel="me"></a></li><?php endif; ?>
				<?php if(theme_get_setting('gplus_url')!=''): ?><li><a href="<?php echo theme_get_setting('gplus_url'); ?>" class="gplus icon" target="_blank" rel="me"></a></li><?php endif; ?>
				<?php if(theme_get_setting('linkedin_url')!=''): ?><li><a href="<?php echo theme_get_setting('linkedin_url'); ?>" class="linkedin icon" target="_blank" rel="me"></a></li><?php endif; ?>
				<?php if(theme_get_setting('twitter_url')!=''): ?><li><a href="<?php echo theme_get_setting('twitter_url'); ?>" class="twitter icon" target="_blank" rel="me"></a></li><?php endif; ?>
				<?php if(theme_get_setting('facebook_url')!=''): ?><li><a href="<?php echo theme_get_setting('facebook_url'); ?>" class="facebook icon" target="_blank" rel="me"></a></li><?php endif; ?>
			<?php endif; ?>
				<li>
					<?php if ($page['search_box']): ?><!-- start search box region -->
						<div class="search-box">
							<?php print render($page['search_box']); ?>
						</div> <!-- end search box region -->
					<?php endif; ?>
				</li>
		</div> <!-- end #social -->
	</div> <!-- /.container -->
</div> <!-- /#header -->
<div class="clear"></div>
<div id="nav-body">
	<?php if (theme_get_setting('show_sticky_menu')): ?><div id="sticky-nav"><?php endif; ?>
    <div class="container clearfix">
		<nav id="main-navigation" class="main-menu clearfix" role="navigation">
			<?php if ($page['navigation']) :?>
				<?php print drupal_render($page['navigation']); ?>
			<?php else : ?>
				<?php if (module_exists('i18n_menu')) {
				$main_menu_tree = i18n_menu_translated_tree(variable_get('menu_main_links_source', 'main-menu'));
				} else { $main_menu_tree = menu_tree(variable_get('menu_main_links_source', 'main-menu')); }
				print drupal_render($main_menu_tree); ?>
			<?php endif; ?>
		</nav><!-- EOF: #main-navigation -->
    </div><!-- /main-menu -->
	<div id="mobile-nav-holder">
	<div class="show-hide"><a href="#"></a></div>
	<div id="mobile-nav-container">
		<div class="show-hide"><a href="#">X - MENU</a></div>
		<div id="mobile-nav">
			<?php if ($page['navigation']) :?>
				<?php print drupal_render($page['navigation']); ?>
			<?php else : ?>
				<?php if (module_exists('i18n_menu')) {
				$main_menu_tree = i18n_menu_translated_tree(variable_get('menu_main_links_source', 'main-menu'));
				} else { $main_menu_tree = menu_tree(variable_get('menu_main_links_source', 'main-menu')); }
				print drupal_render($main_menu_tree); ?>
			<?php endif; ?>
		</div><!-- /#mobile-nav -->
	</div><!-- /#mobile-nav-container -->
	</div><!-- /#mobile-nav-holder -->
<?php if (theme_get_setting('show_sticky_menu')): ?></div><!--/#sticky-nav--><?php endif; ?>
</div><!-- /#nav-body -->
<div class="clear"></div>
<?php if (theme_get_setting('breadcrumb_display_show')): ?>
<div id="breadcrumb">
	<div class="container" class="clearfix">
		<?php if ($breadcrumb): print $breadcrumb; endif;?>
	</div>
</div> <!-- /#breadcrumb -->
<?php endif; ?>