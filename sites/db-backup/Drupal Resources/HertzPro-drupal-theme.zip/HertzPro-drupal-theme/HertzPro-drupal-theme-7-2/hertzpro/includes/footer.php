</div> <!-- /#content from header-->
<div class="clear"></div>
<footer id="footer" role="contentinfo">
	<div class="container">	
		<?php if ($page['footer_one']): ?>
			<div class="footer-one">
				<?php print render($page['footer_one']); ?>
			</div>
		<?php endif; ?>
		
		<?php if ($page['footer_two']): ?>
			<div class="footer-two">
				<?php print render($page['footer_two']); ?>
			</div>
		<?php endif; ?>
		
		<?php if ($page['footer_three']): ?>	
			<div class="footer-three">
				<?php print render($page['footer_three']); ?>
			</div>
		<?php endif; ?>
	</div> <!-- /.container -->
</footer> <!-- /#footer -->
<div class="clear"></div>
<div id="footer-bottom">
	<div class="container">	
		<?php if (theme_get_setting('footer_copyright_show')) {
			if (theme_get_setting('footer_copyright_text')=='') { ?>
				<div id="copyright">Copyright &copy; <?php echo date("Y"); ?>, <?php print $site_name; ?></div>
			<?php } else {
				echo theme_get_setting('footer_copyright_text');
			}		
		} ?>
		<?php print render($page['footer']) ?>
	</div> <!-- /.container -->
</div> <!-- /#footer-bottom -->
<?php if (theme_get_setting('scroll_to_top')): ?>
	<div class="scrolltop"></div>
<?php endif; ?>
<?php if (theme_get_setting('analytic_enable')): ?>
	<?php echo theme_get_setting('analytic_code'); ?>
<?php endif; ?>
<?php if(theme_get_setting('extra_css')!=''): ?>
<style type="text/css">
<?php echo theme_get_setting('extra_css'); ?>

</style>
<?php endif; ?>