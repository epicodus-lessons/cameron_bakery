<?php if ($page['sidebar_second']): ?>
	<aside id="sidebar-second" role="complementary" class="sidebar clearfix">
	  <?php print render($page['sidebar_second']); ?>
	</aside>  <!-- /#sidebar-second -->
<?php endif; ?>