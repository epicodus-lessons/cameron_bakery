<?php
/**
Extra Theme settings
*/
function hertzpro_form_system_theme_settings_alter(&$form, &$form_state) {
	$form['hertzpro_settings'] = array(
		'#type' => 'fieldset',
		'#title' => t('hertzpro Theme Settings'),
		'#description'   => t("<a href='http://drupar.com/theme/hertzpro' target='_blank'>Theme Homepage</a> || <a href='http://demo.drupar.com/hertzpro' target='_blank'>Live Demo</a> || <a href='http://drupar.com/hertzpro-theme-documentation' target='_blank'>Knowledgebase</a> || <a href='http://drupar.com/forum' target='_blank'>Theme Support</a>"),
		'#collapsible' => False,
		'#collapsed' => False,
	);
	$form['hertzpro_settings']['tabs'] = array(
		'#type' => 'vertical_tabs',
	);
    $form['hertzpro_settings']['tabs']['header'] = array(
        '#type' => 'fieldset',
        '#title' => t('Header'),
        '#collapsible' => TRUE,
        '#collapsed' => FALSE,
    );
    $form['hertzpro_settings']['tabs']['header']['message_bar'] = array(
        '#type' => 'fieldset',
        '#title' => t('Header Message Bar'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );
    $form['hertzpro_settings']['tabs']['header']['message_bar']['header_message_bar'] = array(
		'#type' => 'checkbox',
		'#title' => t('jQuery Message Bar in header'),
		'#default_value' => theme_get_setting('header_message_bar'),
		'#description'   => t("Check this option to show sliding message bar in header. Uncheck to hide."),
    );
    $form['hertzpro_settings']['tabs']['header']['sticky_menu'] = array(
        '#type' => 'fieldset',
        '#title' => t('Sticky Main Menu'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );
    $form['hertzpro_settings']['tabs']['header']['sticky_menu']['show_sticky_menu'] = array(
		'#type' => 'checkbox',
		'#title' => t('Enable Sticky Main Menu'),
		'#default_value' => theme_get_setting('show_sticky_menu'),
		'#description'   => t("Check this option to enable sticky main menu in header. Uncheck to disable."),
    );
    $form['hertzpro_settings']['tabs']['header']['social_icon'] = array(
        '#type' => 'fieldset',
        '#title' => t('Social icons in header'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );
    $form['hertzpro_settings']['tabs']['header']['social_icon']['social_icons'] = array(
		'#type' => 'checkbox',
		'#title' => t('Show social (twitter, facebook , google+, Linkedin.) icons in header'),
		'#default_value' => theme_get_setting('social_icons'),
		'#description'   => t("Check this option to show social icons in header. Uncheck to hide all icons.<br />Leave the field blank if you want to hide any particular icon."),
    );
    $form['hertzpro_settings']['tabs']['header']['social_icon']['facebook_url'] = array(
		'#type' => 'textfield',
		'#title' => t('Facebook profile url'),
		'#default_value' => theme_get_setting('facebook_url'),
		'#description'   => t("Enter your facebook profile url. Example: https://www.facebook.com/google"),
    );
    $form['hertzpro_settings']['tabs']['header']['social_icon']['twitter_url'] = array(
		'#type' => 'textfield',
		'#title' => t('Twitter profile url'),
		'#default_value' => theme_get_setting('twitter_url'),
		'#description'   => t("Enter your twitter profile url. Example: https://twitter.com/google"),
    );
    $form['hertzpro_settings']['tabs']['header']['social_icon']['linkedin_url'] = array(
		'#type' => 'textfield',
		'#title' => t('Linkedin Plus profile url'),
		'#default_value' => theme_get_setting('linkedin_url'),
		'#description'   => t("Enter your linkedin profile url. Example: http://www.linkedin.com/company/google"),
    );
    $form['hertzpro_settings']['tabs']['header']['social_icon']['gplus_url'] = array(
		'#type' => 'textfield',
		'#title' => t('Google Plus profile url'),
		'#default_value' => theme_get_setting('gplus_url'),
		'#description'   => t("Enter your Google Plus profile url. Example: https://plus.google.com/+google"),
    );
    $form['hertzpro_settings']['tabs']['header']['social_icon']['pinterest_url'] = array(
		'#type' => 'textfield',
		'#title' => t('Pinterest profile url'),
		'#default_value' => theme_get_setting('pinterest_url'),
		'#description'   => t("Enter your pinterest profile url. Example: http://www.pinterest.com/google"),
    );
    $form['hertzpro_settings']['tabs']['header']['social_icon']['instagram_url'] = array(
		'#type' => 'textfield',
		'#title' => t('Instagram profile url'),
		'#default_value' => theme_get_setting('instagram_url'),
		'#description'   => t("Enter your Instagram profile url. Example: http://instagram.com/google"),
    );
    $form['hertzpro_settings']['tabs']['header']['social_icon']['youtube_url'] = array(
		'#type' => 'textfield',
		'#title' => t('YouTube profile url'),
		'#default_value' => theme_get_setting('youtube_url'),
		'#description'   => t("Enter your YouTube profile url. Example: https://www.youtube.com/user/google"),
    );
    $form['hertzpro_settings']['tabs']['homepage_slider'] = array(
        '#type' => 'fieldset',
        '#title' => t('Homepage Slider'),
        '#collapsible' => TRUE,
        '#collapsed' => FALSE,
    );
    $form['hertzpro_settings']['tabs']['homepage_slider']['homepage_sliders'] = array(
        '#type' => 'fieldset',
        '#title' => t('Enable / Disable homepage slider'),
        '#collapsible' => TRUE,
        '#collapsed' => FALSE,
    );
    $form['hertzpro_settings']['tabs']['homepage_slider']['homepage_sliders']['homepage_slider_show'] = array(
        '#type' => 'checkbox',
        '#title' => t('Enable / Disable homepage slider'),
        '#default_value' => theme_get_setting('homepage_slider_show'),
		'#description'   => t("Check this option to show slider on homepage. Uncheck to hide."),
    );
    $form['hertzpro_settings']['tabs']['homepage_slider']['homepage_slider_code'] = array(
        '#type' => 'fieldset',
        '#title' => t('Slider Code'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );
    $form['hertzpro_settings']['tabs']['homepage_slider']['homepage_slider_code']['homepage_slider_codes'] = array(
        '#type' => 'textarea',
        '#title' => t('Enter your slider code'),
        '#default_value' => theme_get_setting('homepage_slider_codes'),
		'#description'   => t("Enter your homepage slider code here. Find sample code in /sample-content folder"),
    );
    $form['hertzpro_settings']['tabs']['breadcrumb'] = array(
        '#type' => 'fieldset',
        '#title' => t('Breadcrumb'),
        '#collapsible' => TRUE,
        '#collapsed' => FALSE,
    );
    $form['hertzpro_settings']['tabs']['breadcrumb']['breadcrumb_display'] = array(
        '#type' => 'fieldset',
        '#title' => t('Enable / Disable breadcrumb navigation'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );
    $form['hertzpro_settings']['tabs']['breadcrumb']['breadcrumb_display']['breadcrumb_display_show'] = array(
        '#type' => 'checkbox',
        '#title' => t('Enable / Disable breadcrumb navigation'),
        '#default_value' => theme_get_setting('breadcrumb_display_show'),
		'#description'   => t("Check this option to show breadcrumb navigation link. Uncheck to hide."),
    );
    $form['hertzpro_settings']['tabs']['breadcrumb']['breadcrumb_separator'] = array(
        '#type' => 'fieldset',
        '#title' => t('Breadcrumb Separator'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );
    $form['hertzpro_settings']['tabs']['breadcrumb']['breadcrumb_separator']['breadcrumb_separators'] = array(
        '#type' => 'textfield',
        '#title' => t('Breadcrumb links separator'),
        '#default_value' => theme_get_setting('breadcrumb_separators'),
		'#description'   => t("Enter breadcrumb separator"),
    );
    $form['hertzpro_settings']['tabs']['footer'] = array(
        '#type' => 'fieldset',
        '#title' => t('Footer'),
        '#collapsible' => TRUE,
        '#collapsed' => FALSE,
    );
    $form['hertzpro_settings']['tabs']['footer']['footer_copyright'] = array(
        '#type' => 'fieldset',
        '#title' => t('Show / Hide copyright text in footer'),
        '#collapsible' => TRUE,
        '#collapsed' => FALSE,
    );
    $form['hertzpro_settings']['tabs']['footer']['footer_copyright']['footer_copyright_show'] = array(
        '#type' => 'checkbox',
        '#title' => t('Show or hide copyright text in footer'),
        '#default_value' => theme_get_setting('footer_copyright_show'),
		'#description'   => t("Check this option to show copyright text in footer. Uncheck to hide."),
    );
    $form['hertzpro_settings']['tabs']['footer']['footer_copyright']['footer_copyright_text'] = array(
        '#type' => 'textfield',
        '#title' => t('Footer Copyright Text'),
        '#default_value' => theme_get_setting('footer_copyright_text'),
		'#description'   => t("Enter you website copyright text to override default text"),
    );
    $form['hertzpro_settings']['tabs']['footer']['scroll_top'] = array(
        '#type' => 'fieldset',
        '#title' => t('Scroll to top footer'),
        '#collapsible' => TRUE,
        '#collapsed' => FALSE,
    );
    $form['hertzpro_settings']['tabs']['footer']['scroll_top']['scroll_to_top'] = array(
        '#type' => 'checkbox',
        '#title' => t('Enable / Disable scroll to top button'),
        '#default_value' => theme_get_setting('scroll_to_top'),
		'#description'   => t("Check this option to show scroll to top button in footer. Uncheck to hide."),
    );
    $form['hertzpro_settings']['tabs']['extra'] = array(
        '#type' => 'fieldset',
        '#title' => t('Extra Settings'),
        '#collapsible' => TRUE,
        '#collapsed' => FALSE,
    );
    $form['hertzpro_settings']['tabs']['extra']['analytic'] = array(
        '#type' => 'fieldset',
        '#title' => t('Google Analytic'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );
    $form['hertzpro_settings']['tabs']['extra']['analytic']['analytic_enable'] = array(
        '#type' => 'checkbox',
        '#title' => t('Enable / Disable Google Analytic'),
        '#default_value' => theme_get_setting('analytic_enable'),
		'#description'   => t("Check this optiotn to enable Google Analytic on your website. Uncheck to disable."),
    );
    $form['hertzpro_settings']['tabs']['extra']['analytic']['analytic_code'] = array(
        '#type' => 'textarea',
        '#title' => t('Google Analytic Code'),
        '#default_value' => theme_get_setting('analytic_code'),
		'#description'   => t("Enter your Google analytic code here"),
    );
    $form['hertzpro_settings']['tabs']['extra']['css'] = array(
        '#type' => 'fieldset',
        '#title' => t('Custom CSS'),
        '#collapsible' => TRUE,
        '#collapsed' => TRUE,
    );
    $form['hertzpro_settings']['tabs']['extra']['css']['extra_css'] = array(
        '#type' => 'textarea',
        '#title' => t('Put your custom CSS codes in below box'),
        '#default_value' => theme_get_setting('extra_css'),
		'#description'   => t("Add custom CSS to add your own styling to the theme"),
    );
}
