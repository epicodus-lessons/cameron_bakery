/*----------------------------------------------*/
/*	Load
/*---------------------------------------------*/	
jQuery(document).ready(function() {
/*----------------------------------------------*/
/*		     Top Message Bar
/*----------------------------------------------*/
	jQuery(".open-message-bar").click(function() {
		jQuery("#message-bar").slideToggle();
		jQuery(this).toggleClass("close-message-bar");
	});
/*----------------------------------------------*/
/*	Sticky Nav
/*---------------------------------------------*/
	// Adding smaller class after refreshing the page
	if(jQuery(document).scrollTop() > 100) {
		jQuery('#sticky-nav').addClass('sticky-nav');
	}
	// Navigation height change
	jQuery(window).scroll(function () {
		if (jQuery(this).scrollTop() > 100) {
			jQuery('#sticky-nav').addClass('sticky-nav');

		} else {
			jQuery('#sticky-nav').removeClass('sticky-nav');
		}
	});
/*	Expandable search box
/*---------------------------------------------*/		
	jQuery(".search-box .form-text").focus(function() {
        jQuery(this).stop().animate({'width' : '200px', 'padding-left' : '40px'});
    });
	jQuery(".search-box .form-text").blur(function() {
        jQuery(this).stop().animate({'width' : '34px', 'padding-left' : '0px'});
    });
/*----------------------------------------------*/
/*	Mobile navigation
/*---------------------------------------------*/
	jQuery("#mobile-nav-container").hide();
	jQuery(".show-hide").click(function() {
		jQuery("#mobile-nav-container").slideToggle();
		return false;
	});
	jQuery("#mobile-nav-container ul.menu > li.expanded > a").after("<span class='plus'> + </span>");
	jQuery("#mobile-nav-container ul.menu li.expanded .plus").click(function() {
		jQuery (this).next('ul').slideToggle();
	});
	jQuery("#mobile-nav-container ul.menu li ul li.expanded a").after("<span class='plus2'> + </span>");
	jQuery("#mobile-nav-container ul.menu li ul li.expanded .plus2").click(function() {
		jQuery (this).closest('li').find('ul.menu').slideToggle();
	});
/*----------------------------------------------*/
/*	Slider
/*---------------------------------------------*/
	jQuery('.slider').fractionSlider({
		'fullWidth': 			false,
		'controls': 			true, 
		'pager': 				true,
		'responsive': 			true,
		'dimensions': 			"940,350",
	    'increase': 			false,
		'pauseOnHover': 		true,
		'slideEndAnimation': 	true
	});
/*----------------------------------------------*/
/*	Toggle
/*---------------------------------------------*/
	jQuery(".toggle .toggle-content").hide();
	jQuery(".toggle .toggle-title").click(function() {
		jQuery(this).next('.toggle-content').slideToggle(300);
		jQuery(this).toggleClass('active-toggle')
		return false;
	});
/*----------------------------------------------*/
/*	Accordion 1
/*---------------------------------------------*/
	var head = jQuery(".accordion .accordion-title"), para = jQuery(".accordion .accordion-content"); // select heading and para and save as variable
	para.hide().eq(0).show(); // hide all para except first
	head.eq(0).addClass("active-accordion"); // add active-accordion class to first title
	head.click(function() {
		var current = jQuery(this); // save the heading for easy referral
		current.siblings(".accordion-content").slideUp(); // hide all para
		current.next(".accordion .accordion-content").slideDown(); // show the para next to clicked heading
		current.siblings(".accordion .accordion-title").removeClass('active-accordion'); // remove active-accordion class from all siblings tiles
		current.addClass("active-accordion"); // add class active-accordion to cliecked title
	});
/*----------------------------------------------*/
/*	Accordion 2
/*---------------------------------------------*/	
	var head2 = jQuery(".accordion2 .accordion-title"), para2 = jQuery(".accordion2 .accordion-content"); // select heading and para and save as variable
	para2.hide(); // hide all para
	head2.click(function() {
		var current2 = jQuery(this); // save the heading for easy referral
		current2.siblings(".accordion2 .accordion-content").slideUp(); // hide all content regions
		current2.next(".accordion2 .accordion-content").slideDown(); // show the para next to clicked heading
		current2.siblings(".accordion2 .accordion-title").removeClass('active-accordion'); // remove active-accordion class from all titles
		current2.addClass("active-accordion"); // add class active-accordion to clicked title
	});
/*----------------------------------------------*/
/*	Accordion 3
/*---------------------------------------------*/
	var head3 = jQuery(".accordion3 .accordion-title"), para3 = jQuery(".accordion3 .accordion-content"); // select heading and para and save as variable
	para3.hide().eq(0).show(); // hide all para except first one
	head3.eq(0).addClass("active-accordion"); // add active-accordion class to first title
	head3.click(function() {
		var current3 = jQuery(this); // save the heading for easy referral
		if ( current3.next(".accordion-content").is(":hidden") )
		{
			current3.siblings(".accordion3 .accordion-content").slideUp();
			current3.next(".accordion-content").slideDown();
			current3.siblings(".accordion3 .accordion-title").removeClass('active-accordion'); // remove active-accordion class from all siblings titles
			current3.addClass("active-accordion"); // add class active-accordion to clicked title
		} else {
			current3.next(".accordion-content").slideUp();
			current3.removeClass("active-accordion"); // add class active-accordion to clicked title
		}

	});
/*----------------------------------------------*/
/*	Accordion 4
/*---------------------------------------------*/
	var head4 = jQuery(".accordion4 .accordion-title"), para4 = jQuery(".accordion4 .accordion-content"); // select heading and para and save as variable
	para4.hide(); // hide all para
	head4.click(function() {
		var current4 = jQuery(this); // save the heading for easy referral
		if ( current4.next(".accordion-content").is(":hidden") )
		{
			current4.siblings(".accordion4 .accordion-content").slideUp();
			current4.next(".accordion-content").slideDown();
			current4.siblings(".accordion4 .accordion-title").removeClass('active-accordion'); // remove active-accordion class from all siblings titles
			current4.addClass("active-accordion"); // add class active-accordion to clicked title
		} else {
			current4.next(".accordion-content").slideUp();
			current4.removeClass("active-accordion"); // add class active-accordion to clicked title
		}

	});
/*----------------------------------------------*/
/*	Tabs
/*---------------------------------------------*/
	jQuery(".nav-tabs li:first-child").addClass('active');
	jQuery("ul.nav-tabs").addClass('nav');
	jQuery(".nav-tabs li a").attr( "data-toggle", "tab");
	jQuery(".tab-content .tab-pane:first-child").addClass('in active');
	jQuery(".tab-content .tab-pane").addClass('fade');	
/*----------------------------------------------*/
/*	Skill Bar
/*---------------------------------------------*/
	jQuery('.skillbar').each(function(){
		jQuery(this).find('.skillbar-bar').animate({
		width:jQuery(this).attr('data-percent')
		},3000);
	});
/*----------------------------------------------*/
/*	Alert box
/*---------------------------------------------*/
	jQuery(".delete-button").click(function(e) {
		jQuery(e.target).closest(".alert-box, .alert-info, .alert-error, .alert-success, .alert-warning").fadeOut();
	});
	
/*----------------------------------------------*/
/*	ToolTip
/*---------------------------------------------*/
	jQuery(".tip").tooltip();
/*----------------------------------------------*/
/*	Portfolio Filter
/*---------------------------------------------*/				
	jQuery(function(){     
	    jQuery('#filter, #team, #portfolio').mixitup();   
	});
/*----------------------------------------------*/
/*	Flexisel Slider
/*---------------------------------------------*/
	jQuery("#testimonials").flexisel({
		autoPlay: true,
		autoPlaySpeed: 5000,
		enableResponsiveBreakpoints: false,
		visibleItems: 1 
	});
	jQuery("#clients").flexisel({
		autoPlay: true,
		enableResponsiveBreakpoints: false,
		visibleItems: 3 
	});
	jQuery("#carousel").flexisel({
		autoPlay: true,
		autoPlaySpeed: 6000,
		visibleItems: 4 
	});
	jQuery("#carousel2").flexisel({
		autoPlay: true,
		autoPlaySpeed: 6000,
		visibleItems: 4 
	});
	jQuery("#carousel3").flexisel({
		autoPlay: true,
		autoPlaySpeed: 6000,
		visibleItems: 4 
	});
/*----------------------------------------------*/
/*	Go to top
/*---------------------------------------------*/			
	jQuery(window).scroll(function(){
		if (jQuery(this).scrollTop() > 80) {
			jQuery(".scrolltop").fadeIn('slow');
		} else {
			jQuery(".scrolltop").fadeOut('slow');
		}
	});
	jQuery(".scrolltop").click(function(){
		jQuery("html, body").animate({ scrollTop: 0 }, 'slow');
	});
/*----------------------------------------------*/
/*	Drop down menu
/*---------------------------------------------*/
	if (jQuery("#main-navigation, #main-navigation .content").length && jQuery()) {
		var arrowimages = {
		    down: ["downarrowclass"],
		    right: ["rightarrowclass"]
		}
		var jqueryslidemenu = {
		    animateduration: {
		        over: 200,
		        out: 100
		    },
		    //duration of slide in/ out animation, in milliseconds
		    buildmenu: function(menuid, arrowsvar) {
		        jQuery(document).ready(function(jQuery) {
		            var jQuerymainmenu = jQuery("#" + menuid + ">ul.menu:not(.sf-menu)")
		            var jQueryheaders = jQuerymainmenu.find("ul").parent()
		            jQueryheaders.each(function(i) {
		                var jQuerycurobj = jQuery(this)
		                var jQuerysubul = jQuery(this).find("ul:eq(0)")
		                this._dimensions = {
		                    w: this.offsetWidth,
		                    h: this.offsetHeight,
		                    subulw: jQuerysubul.outerWidth(),
		                    subulh: jQuerysubul.outerHeight()
		                }
		                this.istopheader = jQuerycurobj.parents("ul").length == 1 ? true : false
		                jQuerysubul.css({
		                    top: this.istopheader ? this._dimensions.h + "px" : 0
		                })
		                jQuerycurobj.children("a:eq(0)").css(this.istopheader ? {
		                    paddingRight: arrowsvar.down[2]
		                } : {}).append("<span class=" + (this.istopheader ? arrowsvar.down[0] : arrowsvar.right[0]) + " />")
		                jQuerycurobj.hover(

		                function(e) {
		                    var jQuerytargetul = jQuery(this).children("ul:eq(0)")
		                    this._offsets = {
		                        left: jQuery(this).offset().left,
		                        top: jQuery(this).offset().top
		                    }
		                    var menuleft = this.istopheader ? 0 : this._dimensions.w
		                    menuleft = (this._offsets.left + menuleft + this._dimensions.subulw > jQuery(window).width()) ? (this.istopheader ? -this._dimensions.subulw + this._dimensions.w : -this._dimensions.w) : menuleft
		                    if (jQuerytargetul.queue().length <= 1) //if 1 or less queued animations
		                    jQuerytargetul.css({
		                        left: menuleft + "px",
		                        width: this._dimensions.subulw + "px"
		                    }).slideDown(jqueryslidemenu.animateduration.over)
		                }, function(e) {
		                var jQuerytargetul = jQuery(this).children("ul:eq(0)")
		                    jQuerytargetul.slideUp(jqueryslidemenu.animateduration.out)
		                }) //end hover
		                jQuerycurobj.click(function() {
		                    jQuery(this).children("ul:eq(0)").hide()
		                })
		            }) //end jQueryheaders.each()

		            jQuerymainmenu.find("ul").css({
		                display: "none",
		                visibility: "visible"
		            })

		        }) //end document.ready
		    }
		}
		jqueryslidemenu.buildmenu("main-navigation .content", arrowimages)
		jqueryslidemenu.buildmenu("main-navigation", arrowimages)
	}
/*----------------------------------------------*/
/*	Hover overlay image
/*---------------------------------------------*/
	jQuery("#carousel li img").before("<span class='roll' ></span>")
	jQuery(".roll").css("opacity","0");
	jQuery(".roll").hover(function () {
		jQuery(this).stop().animate({opacity: .7}, "slow");
	}, function () {
		jQuery(this).stop().animate({opacity: 0}, "slow");
	});
/*----------------------------------------------*/
/*	PreetyPhoto
/*---------------------------------------------*/
	jQuery("#gallery a").attr('rel', 'prettyPhoto');
	jQuery("a[rel^='prettyPhoto']").prettyPhoto();
/*----------------------------------------------*/
/*		     Animated Links
/*----------------------------------------------*/
	jQuery("#sidebar-first li a, #sidebar-second li a, #footer li a").hover(function() {
		jQuery(this).stop().animate({'padding-left': '6px'}, 'fast');
	}, function() {
		jQuery(this).stop().animate({'padding-left':'0px'});
	});
/*----------------------------------------------*/
/*		     Animated on scroll view
/*----------------------------------------------*/
	jQuery('.feature-item, .service-item, animated-item').smoove({
		offset:'10%',
		opacity: '30',
		rotateY: '60deg'
	});
/*----------------------------------------------*/
/*	End Load
/*---------------------------------------------*/	
});



